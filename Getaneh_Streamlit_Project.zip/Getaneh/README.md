# Maternal Satisfaction Streamlit App

Project: **Maternal satisfaction among vaginal and cesarean section delivery care services in Bahir Dar city health facilities, Northwest Ethiopia: Application of Machine Learning**

## Folder contents
- `app.py` — Streamlit interface template
- `requirements.txt` — required Python packages
- `feature_columns.json` — must be replaced with the exact model input columns
- `model.joblib` — **not included**; export the fitted model from your Colab notebook
- `scaler.joblib` — **not included**; include only if your trained workflow uses a scaler

## Important setup before deployment
1. In Colab, save the fitted model and (if used) scaler with `joblib.dump(...)`.
2. Use the exact same preprocessing at prediction time as during training. For a scikit-learn workflow, a fitted `Pipeline` that includes preprocessing is often safer than saving a scaler separately.
3. Replace `feature_columns.json` with the exact columns and order expected by the model. Do not use the example names.
4. Change the generic numeric inputs in `app.py` to the actual variables, coding, and categories from the maternal satisfaction dataset.
5. Never upload patient-identifying information or private raw data to a public repository.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy with Streamlit Community Cloud
1. Push the files to a GitHub repository.
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Choose the repository, branch, and `app.py` as the main file.
4. Deploy.

**This is a starter template, not a completed predictive application.** The actual trained model, preprocessing, and exact dataset feature names must come from your Colab project before reliable predictions can be made.
