import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import streamlit as st

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model.joblib"
SCALER_PATH = BASE_DIR / "scaler.joblib"
FEATURES_PATH = BASE_DIR / "feature_columns.json"

st.set_page_config(page_title="Maternal Satisfaction Prediction", page_icon="🏥", layout="centered")
st.title("Maternal Satisfaction Prediction")
st.caption(
    "Maternal satisfaction among vaginal and cesarean section delivery care services "
    "in Bahir Dar city health facilities, Northwest Ethiopia"
)

st.warning(
    "Setup required: copy your trained model.joblib, scaler.joblib (only if your model uses a scaler), "
    "and the exact feature_columns.json from your Colab training workflow into this folder. "
    "The input fields must match the model's training features and preprocessing exactly."
)

if not FEATURES_PATH.exists():
    st.error("Missing feature_columns.json. Create it from the exact training columns used in Colab.")
    st.code('["feature_1", "feature_2"]  # Replace with the exact model input columns', language="json")
    st.stop()

with open(FEATURES_PATH, "r", encoding="utf-8") as f:
    feature_columns = json.load(f)

if not isinstance(feature_columns, list) or not feature_columns:
    st.error("feature_columns.json must contain a non-empty JSON list of feature names.")
    st.stop()

if not MODEL_PATH.exists():
    st.error("Missing model.joblib. Export your fitted model from Colab and put it in this folder.")
    st.stop()

model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH) if SCALER_PATH.exists() else None

st.subheader("Enter the mother's care and background information")
st.info(
    "Replace these generic input controls with the real categories and coding from your dataset "
    "(for example, the same one-hot encoding and reference categories used during training)."
)

values = {}
for feature in feature_columns:
    values[feature] = st.number_input(feature, value=0.0, step=1.0)

if st.button("Predict satisfaction", type="primary"):
    input_df = pd.DataFrame([values], columns=feature_columns)
    try:
        transformed = scaler.transform(input_df) if scaler is not None else input_df
        prediction = model.predict(transformed)[0]
        st.subheader("Prediction")
        st.write("Predicted class:", "**Satisfied**" if int(prediction) == 1 else "**Not satisfied**")
        if hasattr(model, "predict_proba"):
            probability = float(model.predict_proba(transformed)[0][1])
            st.metric("Estimated probability of satisfaction", f"{probability:.1%}")
            st.progress(max(0.0, min(1.0, probability)))
        st.caption("This is a machine-learning estimate, not a clinical decision or a substitute for service-quality assessment.")
    except Exception as exc:
        st.error(f"Prediction failed: {exc}")
        st.write("Check that feature names, order, data types, and preprocessing match the training notebook exactly.")
